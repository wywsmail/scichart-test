<template>
  <div class="container">
    <div id="scichart-root" style="width: 100%; height: 800px; margin: auto"></div>
  </div>
</template>

<script lang="ts"></script>

<style scoped></style>
