<template>
  <div class="container">
    <nav aria-label="Page navigation example">
      <ul class="pagination justify-content-end">
        <li class="page-item disabled">
          <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
        </li>
        <li class="page-item" v-for="n in pageNumber" :key="n">
          <a
            class="page-link"
            href="#"
            @click.prevent="requestDiagnoses(n * 10 - 9, n * 10)"
            >{{ n }}</a
          >
        </li>
        <li class="page-item">
          <a class="page-link" href="#">Next</a>
        </li>
      </ul>
    </nav>
  </div>
</template>

<script>
import { computed } from "vue";
import { useRequestDiagnoses } from "@/composition/index";
import { countNumber } from "@/composition/store";
export default {
  setup() {
    const { requestDiagnoses } = useRequestDiagnoses();
    const pageNumber = computed(() => {
      return Math.ceil(countNumber.value / 10);
    });
    console.log(countNumber.value);
    console.log(pageNumber.value);
    return { countNumber, pageNumber, requestDiagnoses };
  }
};
</script>

<style></style>
