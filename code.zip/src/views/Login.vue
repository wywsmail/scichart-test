<template>
  <h2>Login</h2>
  <Login></Login>
</template>

<script>
import Login from "@/components/LoginComponent";
export default {
  components: {
    Login
  }
};
</script>

<style scoped></style>
