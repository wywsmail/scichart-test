<template>
  <div id="carouselExampleControls" class="carousel slide home" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img
          src="../assets/mockup-graphics-i1iqQRLULlg-unsplash.jpeg"
          class="img-fluid"
          alt="..."
        />
      </div>
      <div class="carousel-item">
        <img
          src="../assets/30daysreplay-germany-R0bS-dhsgZs-unsplash.jpeg"
          class="img-fluid"
          alt="..."
        />
      </div>
      <div class="carousel-item">
        <img
          src="../assets/tim-cooper-BvS7q4yFQt4-unsplash.jpeg"
          class="img-fluid"
          alt="..."
        />
      </div>
    </div>
    <a
      class="carousel-control-prev"
      href="#carouselExampleControls"
      role="button"
      data-bs-slide="prev"
    >
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </a>
    <a
      class="carousel-control-next"
      href="#carouselExampleControls"
      role="button"
      data-bs-slide="next"
    >
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </a>
  </div>
</template>

<script></script>
